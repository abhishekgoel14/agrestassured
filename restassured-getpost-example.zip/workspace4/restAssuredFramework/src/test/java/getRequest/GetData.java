package getRequest;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;


public class GetData {
	
	@Test
	public void testResponseCode()
	{
	Response resp =	post("signin");
	
	int code = resp.getStatusCode();
	System.out.println("Status code is " +code);
	
	Assert.assertEquals(code, 415);
	}

}
