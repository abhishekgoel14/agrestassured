package restAPI;

import io.restassured.config.EncoderConfig;
import io.restassured.config.ObjectMapperConfig;
import io.restassured.http.ContentType;
import io.restassured.internal.http.ContentTypeExtractor;
import io.restassured.mapper.DataToDeserialize;
import io.restassured.mapper.ObjectMapperDeserializationContext;
import io.restassured.mapper.ObjectMapperSerializationContext;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.mapper.factory.GsonObjectMapperFactory;
import io.restassured.mapper.factory.JAXBObjectMapperFactory;
import io.restassured.mapper.factory.Jackson1ObjectMapperFactory;
import io.restassured.mapper.factory.Jackson2ObjectMapperFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import groovy.json.JsonException;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.*;
import io.restassured.response.ResponseBodyData;
import org.apache.commons.lang3.Validate;
import org.apache.commons.logging.Log;
import org.apache.http.ParseException;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.json.JSONString;

//import static ContentType.ANY;
import static io.restassured.internal.assertion.AssertParameter.notNull;
import static io.restassured.mapper.resolver.ObjectMapperResolver.*;
import static org.apache.commons.lang3.StringUtils.containsIgnoreCase;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

public class Post_Delete_PutExample{
	
			
	@Test
	public void test1()
	{
		RequestSpecification  request = RestAssured.given();
		
		request.header("Content-Type", "application/json");
		
		org.json.simple.JSONObject json = new org.json.simple.JSONObject();
		json.put("emailAddress","abhishekgoel14@gmail.com");
		json.put("password","aaaaa123");
		json.put("deviceID","27da3abb1d66369b");
		json.put("deviceModel","postman");
		json.put("platform","postman");
		json.put("version","21");
		
		org.json.simple.JSONObject userJson = new org.json.simple.JSONObject();
		userJson.put("user", json);
		
		request.body(userJson);
	// Your api sign in api uri goes here below
		Response response = request.post("signin");
		
		try{
		//	String res = response.toString(); //new Gson().toJson(response.toString());
			JsonPath jsonPath = new JsonPath(response.getBody().asString());
						
			//JSONObject jsonObject =  new JSONObject(res);
			
			String httpcode = jsonPath.get("httpCode").toString();
			System.out.println("httpCode is == "+ httpcode);

			int code = response.getStatusCode();
						
			if(code == 200){

				 String accessToken = jsonPath.get("access-token").toString();
				 callNextAPI(accessToken);
				 //accessToken = acT;
				System.out.println("access-token == "+accessToken);

			}else{
				System.out.println("failed ");

			}
			
		
		}catch (JsonException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
				
	}
	
	public void callNextAPI(String accessToken){
			quickpaycash quickpaycash= new quickpaycash();
			quickpaycash.cashpayment(accessToken);
			
			activity activity = new activity();
			activity.reports(accessToken);
			
	}
	
}
