package restAPI;

import io.restassured.config.EncoderConfig;
import io.restassured.config.ObjectMapperConfig;
import io.restassured.http.ContentType;
import io.restassured.internal.http.ContentTypeExtractor;
import io.restassured.mapper.DataToDeserialize;
import io.restassured.mapper.ObjectMapperDeserializationContext;
import io.restassured.mapper.ObjectMapperSerializationContext;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.mapper.factory.GsonObjectMapperFactory;
import io.restassured.mapper.factory.JAXBObjectMapperFactory;
import io.restassured.mapper.factory.Jackson1ObjectMapperFactory;
import io.restassured.mapper.factory.Jackson2ObjectMapperFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import groovy.json.JsonException;
import groovyjarjarantlr.collections.List;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.*;
import io.restassured.response.ResponseBodyData;
import org.apache.commons.lang3.Validate;
import org.apache.commons.logging.Log;
import org.apache.http.ParseException;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.json.JSONString;

//import static ContentType.ANY;
import static io.restassured.internal.assertion.AssertParameter.notNull;
import static io.restassured.mapper.resolver.ObjectMapperResolver.*;
import static org.apache.commons.lang3.StringUtils.containsIgnoreCase;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class activity {
	
	@Test
	public void reports(String accessToken)
	{
		RequestSpecification  request = RestAssured.given();
		
		request.header("Content-Type", "application/json");
		request.header("access-token", accessToken);
		
		System.out.println("access-token == "+accessToken);
// Enter body parameter here below and enter required fields
		//org.json.simple.JSONObject jsonPayment = new org.json.simple.JSONObject();
		org.json.simple.JSONObject json = new org.json.simple.JSONObject();
		json.put("page_start","0");
		json.put("page_size","500");
		json.put("search_keyword","");
		json.put("transaction_type","");
		json.put("date","");
		json.put("date_range", "");
		json.put("payment_method","");
		json.put("processed_by","");
		json.put("customername","");
		json.put("card_last4digit", "");

			
		request.body(json);
	// Reports API end point goes here below
		Response response = request.post("reports");
		
		try{
		    JsonPath jsonPath = new JsonPath(response.getBody().asString());
			
		    // Here we are working with json array storing & retrieving later 
			String type = jsonPath.get("type").toString();
			java.util.List<javax.json.JsonArray> jsonArray  = jsonPath.get("extra.TotalIncTax");
			java.util.List<javax.json.JsonArray> jsonArray1  = jsonPath.get("extra.CreatedDate");
			//javax.json.JsonObject object = jsonArray.get(0).getJsonObject(0);
					
			//String amt = jsonArray.get(0).toString();
     		 //String CreatedDate = jsonPath.get("CreatedDate").toString();
									
			if(type.equals("Success")){

				//System.out.println("Passed Reports API Amount: " +Total );
				System.out.println("Passed Reports API: Amount" +jsonArray.get(0) );
				System.out.println("Passed Reports API: Transaction Date/Time" +jsonArray1.get(0) );

			}else{
				System.out.println("failed case: Reports API not working" + type);

			}
			
		
		}catch (JsonException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
			
	}

}
