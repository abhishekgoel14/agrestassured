package restAPI;

import io.restassured.config.EncoderConfig;
import io.restassured.config.ObjectMapperConfig;
import io.restassured.http.ContentType;
import io.restassured.internal.http.ContentTypeExtractor;
import io.restassured.mapper.DataToDeserialize;
import io.restassured.mapper.ObjectMapperDeserializationContext;
import io.restassured.mapper.ObjectMapperSerializationContext;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.mapper.factory.GsonObjectMapperFactory;
import io.restassured.mapper.factory.JAXBObjectMapperFactory;
import io.restassured.mapper.factory.Jackson1ObjectMapperFactory;
import io.restassured.mapper.factory.Jackson2ObjectMapperFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import groovy.json.JsonException;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.*;
import io.restassured.response.ResponseBodyData;
import org.apache.commons.lang3.Validate;
import org.apache.commons.logging.Log;
import org.apache.http.ParseException;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.json.JSONString;

//import static ContentType.ANY;
import static io.restassured.internal.assertion.AssertParameter.notNull;
import static io.restassured.mapper.resolver.ObjectMapperResolver.*;
import static org.apache.commons.lang3.StringUtils.containsIgnoreCase;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

public class quickpaycash {
	
	@Test
	public void cashpayment(String accessToken)
	{
		RequestSpecification  request = RestAssured.given();
		
		request.header("Content-Type", "application/json");
		request.header("access-token", accessToken);
		
		System.out.println("access-token == "+accessToken);
// Showing example below if you have nested value inside one json object, here we will fetch it and save in one json object and then retrive later and hitting post request
		org.json.simple.JSONObject jsonPayment = new org.json.simple.JSONObject();
		jsonPayment.put("paymentMethod","1");
		jsonPayment.put("amount","10");
		
		
		org.json.simple.JSONObject json = new org.json.simple.JSONObject();
		json.put("operation","quickPayment");
		
		json.put("paymentDetail", jsonPayment);
		
		json.put("latitude","30.704649");
		json.put("longitude","76.717873");
		json.put("timezone","Asia/Kolkata");
		json.put("offlineId", "");

			
		request.body(json);
	// payment api goes here
		Response response = request.post("payment");
		
		try{
		//	String res = response.toString(); //new Gson().toJson(response.toString());
			JsonPath jsonPath = new JsonPath(response.getBody().asString());
						
			String httpcode = jsonPath.get("httpCode");
			System.out.println("httpCode is == "+ httpcode);
			
			
			String msg = jsonPath.get("message").toString();
									
			if(msg.equalsIgnoreCase("Your Transaction was Successful")){

				System.out.println("Passed cash payment: " + msg);

			}else{
				System.out.println("failed cash payment : " + msg);

			}
			
		
		}catch (JsonException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
			
	}

}
